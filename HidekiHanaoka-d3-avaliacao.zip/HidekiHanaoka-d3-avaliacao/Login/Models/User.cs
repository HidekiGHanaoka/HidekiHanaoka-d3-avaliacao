﻿using Login.Repositories;

namespace Login.Models
{

    public class User : UserRepository
    {
        public string IdUser { get; set; } = string.Empty;

        public string Name { get; set; } = string.Empty;
    }
}
