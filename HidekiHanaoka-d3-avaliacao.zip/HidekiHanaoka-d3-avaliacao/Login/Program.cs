﻿using Login.Repositories;
using Login.Models;
using Login.Interfaces;
using System.IO;

namespace login
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string path = "Logs/LoginLogout.txt";
            string? firstCommand;
            string? secondCommand;
            string username;
            string iduser;
            bool acess = false;
            bool login = false;
            bool logout = false;
            bool finish = false;

            UserRepository _user = new();

            do
            {
                Console.WriteLine("Bem-vindo ao programa. Escolha a opção que deseja:\n1 - Acessar\n0 - Cancelar");
                firstCommand = Console.ReadLine();

                if (firstCommand != '0'.ToString() && firstCommand != '1'.ToString())
                {
                    Console.WriteLine("Valor inválido");
                }

                else if (firstCommand == '0'.ToString())
                {
                    Console.WriteLine("Encerrando programa");
                    return;
                }

                else
                {
                    acess = true;
                }

            } while (acess == false);

            do
            {
                login = false;
                logout = false;
                do
                {
                    string? email;
                    string? password;
                    Console.WriteLine("LOGIN\nEmail:");
                    email = Console.ReadLine();
                    Console.WriteLine("Senha:");
                    password = Console.ReadLine();

                    if(email != null && password != null)
                    {
                        if (_user.VerifyLogin(email, password) == true)
                        {
                            login = true;
                            username = _user.getName(email);
                            iduser = _user.getID(email);
                            _user.RegisterLogin(path, username, iduser);
                        }
                    }

                } while (login == false);

                do
                {
                    Console.WriteLine("Bem-vindo à plataforma. Digite a operação a ser feita\n1 - Deslogar\n0 - Encerrar sistema");
                    secondCommand = Console.ReadLine();

                    if (secondCommand != '0'.ToString() && secondCommand != '1'.ToString())
                    {
                        Console.WriteLine("Valor inválido");
                    }

                    if (secondCommand == '1'.ToString())
                    {
                        logout = true;
                    }

                    if (secondCommand == '0'.ToString())
                    {
                        logout = true;
                        finish = true;
                    }

                    if (logout == true)
                    {
                        Console.WriteLine("Logout realizado");
                    }

                } while (logout == false);

            } while (finish == false);

            Console.WriteLine("Encerrando programa");
        }
    }
}
