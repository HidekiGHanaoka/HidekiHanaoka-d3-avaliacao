﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Login.Models;
using Login.Interfaces;

namespace Login.Repositories
{
    public class UserRepository : IUser
    {
        private readonly string stringConexao = "Server=labsoft.pcs.usp.br; Initial Catalog=db_12; User Id=usuario_12; Password=9077879676;";

        public string getID(string email)
        {
            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string querySelect = "SELECT * FROM Usuarios";
                SqlDataReader rdr;
                con.Open();

                using (SqlCommand cmd = new SqlCommand(querySelect, con))
                {
                    rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        if (rdr[2].ToString() == email)
                        {
                            return rdr[0].ToString();
                        }
                    }
                }
            }
            return string.Empty;
        }

        public string getName(string email)
        {
            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string querySelect = "SELECT * FROM Usuarios";
                SqlDataReader rdr;
                con.Open();

                using (SqlCommand cmd = new SqlCommand(querySelect, con))
                {
                    rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        if (rdr[2].ToString() == email)
                        {
                            return rdr[1].ToString();
                        }
                    }
                }
            }
            return string.Empty;
        }

        public bool VerifyLogin(string email, string password)
        {
            bool verified = false;

            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string querySelect = "SELECT * FROM Usuarios";
                SqlDataReader rdr;
                con.Open();

                using (SqlCommand cmd = new SqlCommand(querySelect, con))
                {
                    rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        if(rdr[2].ToString() == email)
                        {
                            if (rdr[3].ToString() == password)
                            {
                                verified = true;
                            }
                        }
                    }
                }
            }

            return verified;
        }
        private static string PrepareLineCSVLogin(string username, string iduser)
        {
            return $"O usuário {username}({iduser}) acessou o sistema às {DateTime.Now.ToString("HH:mm:ss tt")} do dia {DateTime.Today}.";
        }

        public void RegisterLogin(string path, string username, string iduser)
        {
            string folder = path.Split("/")[0];
            string[] line = { PrepareLineCSVLogin(username, iduser) };

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            if (!File.Exists(path))
            {
                File.Create(path).Close();
            }

            File.AppendAllLines(path, line);
        }
    }
}
