﻿using Login.Models;

namespace Login.Interfaces
{
    public interface IUser
    {
        bool VerifyLogin(string email, string password);

        string getID(string email);

        string getName(string email);

        public void RegisterLogin(string path, string username, string iduser);
    }
}
