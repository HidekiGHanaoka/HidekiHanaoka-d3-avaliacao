USE db_12;
GO

CREATE TABLE Usuarios(
	[IdUser] VARCHAR(256) NOT NULL UNIQUE,
	[Name] VARCHAR(256) NOT NULL,
	[Email] VARCHAR(256) NOT NULL,
	[Password] VARCHAR(256) NOT NULL
);
GO

INSERT INTO Usuarios([IdUser],[Name],[Email],[Password])
VALUES('82950150-6a10-48be-9a6f-31afdb057012', 'HidekiGHanaoka', 'admin@email.com', 'admin123');
GO

SELECT * FROM Usuarios;
GO